int initGnuPlot();
int sendDataToGnuPlot(int handle, float x0, float dX, double *buffer, int nbOfChannels, int nbSamples);
int closeGnuPlot();
