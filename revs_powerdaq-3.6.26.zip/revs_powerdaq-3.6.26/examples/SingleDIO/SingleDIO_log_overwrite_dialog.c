/*****************************************************************************/
/*                    Single digital input example                           */
/*                                                                           */
/*  This example shows how to use the powerdaq API to perform a single       */
/*  digital acquisition with a PD2-DIO boards.                               */
/*  The acquisition is performed in a software timed fashion that is         */
/*  appropriate for slow speed acquisition (up to 500Hz).                    */
/*  This example only works on PD2-DIO boards.                               */
/*  For the PDx-MFx and PD2-AO boards look at the SingleDI and SingleDO      */
/*  examples.                                                                */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*      Copyright (C) 2001 United Electronic Industries, Inc.                */
/*      All rights reserved.                                                 */
/*---------------------------------------------------------------------------*/
/*                                                                           */ 
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include "win_sdk_types.h"
#include "powerdaq.h"
#include "powerdaq32.h"

#include "ParseParams.h"


typedef enum _state
{
   closed,
   unconfigured,
   configured,
   running
} tState;

typedef struct _singleDioData
{
   int board;                    // board number to be used for the AI operation
   int handle;                   // board handle
   int nbOfPorts;                // nb of ports of 16 lines to use
   unsigned char OutPorts;       // mask for ports of 16 lines to use for output
   int nbOfSamplesPerPort;       // number of samples per port
   unsigned long portList[64];
   double scanRate;              // sampling frequency on each port
   tState state;                 // state of the acquisition session
} tSingleDioData;


int InitSingleDIO(tSingleDioData *pDioData);
int SingleDIO(tSingleDioData *pDioData);
void CleanUpSingleDIO(tSingleDioData *pDioData);


static tSingleDioData G_DioData;

// exit handler
void SingleDIOExitHandler(int status, void *arg)
{
   CleanUpSingleDIO((tSingleDioData *)arg);
}


int InitSingleDIO(tSingleDioData *pDioData)
{
   Adapter_Info adaptInfo;
   int retVal = 0;

   // get adapter type
   retVal = _PdGetAdapterInfo(pDioData->board, &adaptInfo);
   if (retVal < 0)
   {
      printf("SingleDIO: _PdGetAdapterInfo error %d\n", retVal);
      exit(EXIT_FAILURE);
   }

   if(adaptInfo.atType & atPD2DIO)
      printf("This is a PD2-DIO board\n");
   else
   {
      printf("This board is not a PD2-DIO\n");
      exit(EXIT_FAILURE);
   }

   pDioData->handle = PdAcquireSubsystem(pDioData->board, DigitalIn, 1);
   if(pDioData->handle < 0)
   {
      printf("SingleDIO: PdAcquireSubsystem failed\n");
      exit(EXIT_FAILURE);
   }

   pDioData->state = unconfigured;

   retVal = _PdDIOReset(pDioData->handle);
   if (retVal < 0)
   {
      printf("SingleDIO: PdDInReset error %d\n", retVal);
      exit(EXIT_FAILURE);
   }

   return 0;
}


int SingleDIO(tSingleDioData *pDioData)
{
   int retVal;
   int i, j;
   DWORD value;

//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//This section sets up writing to a log file to keep track of which IO stream faults out.

FILE *f = fopen("log.txt","w");
if (f == NULL) {
     printf("Error opening file!\n");
     exit(1);
}



//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   retVal = _PdDIOEnableOutput(pDioData->handle, pDioData->OutPorts);

   time_t t = time(NULL);  //!!!!!!!!!!!!!!!!!!!!
   struct tm *tm = localtime(&t);  //!!!!!!!!!!!!!!!!!!
   fprintf(f, "PD2-DIO loopback test\n"); //!!!!!!!!!!!!!!!!!!!!!!!!!!
   fprintf(f, "%s\n\n", asctime(tm)); //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   if(retVal < 0)
   {
      printf("SingleDIO: _PdDioEnableOutput failed\n");
      exit(EXIT_FAILURE);
   }
   
   pDioData->state = configured;

   
   pDioData->state = running;

   fprintf(f, "OUTPUT TEST\n\n");     //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   for(i=0; i<pDioData->nbOfSamplesPerPort; i++)
   {
      for(j=0; j<pDioData->nbOfPorts; j++)
      {
         if((1 << j) & pDioData->OutPorts)
         {
            retVal = _PdDIOWrite(pDioData->handle, j, 0xFF);
            if(retVal < 0)
            {
               printf("SingleDIO: _PdDIOWrite error: %d\n", retVal);
               fprintf(f, "SingleDIO: _PdDIOWrite error: %d\n", retVal);
               exit(EXIT_FAILURE);
            }
         }
         else
         {
            retVal = _PdDIORead(pDioData->handle, j, &value);
            if(retVal < 0)
            {
               printf("SingleDIO: _PdDIORead error: %d\n", retVal);
               exit(EXIT_FAILURE);
            }

            printf("Port %d: 0x%x ", j, value);
            fprintf(f, "Port %d: 0x%x \n", j, value);       //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         }
      }

      printf("\n");
}

//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//This section is meant to pass over all IO again and turn off each output.

   fprintf(f, "\n\nOUTPUT OVERWRITE\n\n");     //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

for(i=0; i<pDioData->nbOfSamplesPerPort; i++)
   {
      for(j=0; j<pDioData->nbOfPorts; j++)
      {
         if((1 << j) & pDioData->OutPorts)
         {
            retVal = _PdDIOWrite(pDioData->handle, j, 0x00);
            if(retVal < 0)
            {
               printf("SingleDIO: _PdDIOWrite error: %d\n", retVal);
               exit(EXIT_FAILURE);
            }
         }
         else
         {
            retVal = _PdDIORead(pDioData->handle, j, &value);
            if(retVal < 0)
            {
               printf("SingleDIO: _PdDIORead error: %d\n", retVal);
               exit(EXIT_FAILURE);
            }

            printf("Port %d: 0x%x ", j, value);
            fprintf(f, "Port %d: 0x%x \n", j, value);       //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         }
      }

      printf("\n");

//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



      usleep(1.0E6/pDioData->scanRate);
   }

   fclose(f);         //!!!!!!!!!!!!!!!!!!!!!!!!!

   return retVal;
}


void CleanUpSingleDIO(tSingleDioData *pDioData)
{
   int retVal;
      
   if(pDioData->state == running)
   {
      pDioData->state = configured;
   }

   if(pDioData->state == configured)
   {
      retVal = _PdDIOReset(pDioData->handle);
      if (retVal < 0)
         printf("SingleDI: _PdDIOReset error %d\n", retVal);

      pDioData->state = unconfigured;
   }

   if(pDioData->handle > 0 && pDioData->state == unconfigured)
   {
      retVal = PdAcquireSubsystem(pDioData->handle, DigitalIn, 0);
      if (retVal < 0)
         printf("SingleDI: PdReleaseSubsystem error %d\n", retVal);
   }

   pDioData->state = closed;
}


int main(int argc, char *argv[])
{
   int i;
   PD_PARAMS params = {0, 64, {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63}, 1000.0, 0, 100};
   
   ParseParameters(argc, argv, &params);

   int status = system ("dialog --title 'DIO Test' --yesno 'Welcome to the best DIO test program in the world! Begin test?' 10 25");     //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   printf("\nstatus = %d\n", status);     //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

if(status==0) {
   // initializes acquisition session parameters
   G_DioData.board = params.board;
   G_DioData.nbOfPorts = params.numChannels;
   for(i=0; i<params.numChannels; i++)
       G_DioData.portList[i] = params.channels[i];
   G_DioData.handle = 0;
   G_DioData.OutPorts = 0x06; // use ports 1 and 2 for output
   G_DioData.nbOfSamplesPerPort = params.numSamplesPerChannel;
   G_DioData.scanRate = params.frequency;
   G_DioData.state = closed;

   // setup exit handler that will clean-up the acquisition session
   // if an error occurs
   on_exit(SingleDIOExitHandler, &G_DioData);

   // initializes acquisition session
   InitSingleDIO(&G_DioData);

   // run the acquisition
   SingleDIO(&G_DioData);

   // Cleanup acquisition
   CleanUpSingleDIO(&G_DioData);
}
   return 0;
}

