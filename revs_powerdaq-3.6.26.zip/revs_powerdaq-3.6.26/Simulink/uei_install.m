function uei_install()

uei_lib = [matlabroot, '/toolbox/uei'];
addpath(uei_lib);
savepath;

